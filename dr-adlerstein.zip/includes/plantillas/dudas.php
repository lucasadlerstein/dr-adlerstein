<div class="bg-dudas parallax">
    <div class="fondo filtro-primario-fuerte pad-70">
        <div class="container">
            <div class="titulo text-center">
                <h2 class="titulo-seccion texto-blanco">¿Tenés dudas?</h2>
                <div class="descripcion-seccion mb-4">
                    <p class="texto-blanco">
                        Escribime sin compromiso
                    </p>
                </div>
                <div class="botones">
                    <div class="unBoton">
                            <a target="_blank" href="https://wa.me/5491124094837" class="btn-icono bg-wpp texto-blanco">
                            <i class="lab la-whatsapp" style="font-size:20px;"></i> Enviar WhatsApp
                        </a>
                    </div>
                    <div class="unBoton">
                        <a href="contacto" class="btn-icono bg-blanco texto-primario">
                    Quiero Contactarme
                    </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>