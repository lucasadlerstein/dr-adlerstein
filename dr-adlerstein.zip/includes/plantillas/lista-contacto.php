<!-- <div class="item-info">
    <i class="las la-phone"></i>
    <div class="item-textos">
        <h3>Telefono</h3>
        <a href="tel:5491124094837">+54 9 11 2409 4837</a>
    </div>
</div> -->
<div class="item-info">
    <i class="lab la-whatsapp"></i>
    <div class="item-textos">
        <h3>WhatsApp BELGRANO</h3>
        <a href="https://wa.me/5491124094837?text=Hola,%20quisiera%20consultar%20sobre%20.....%20en%20el%20consultorio%20de%20Belgrano." target="_blank">Enviar mensaje</a>
    </div>
</div>
<div class="item-info">
    <i class="lab la-whatsapp"></i>
    <div class="item-textos">
        <h3>WhatsApp PALERMO</h3>
        <a href="https://wa.me/5491124094837?text=Hola,%20quisiera%20consultar%20sobre%20.....%20en%20el%20consultorio%20de%20Palermo." target="_blank">Enviar mensaje</a>
    </div>
</div>
<div class="item-info">
    <i class="lab la-whatsapp"></i>
    <div class="item-textos">
        <h3>WhatsApp SAN ISIDRO</h3>
        <a href="https://wa.me/5491124094837?text=Hola,%20quisiera%20consultar%20sobre%20.....%20en%20el%20consultorio%20de%20San%20Isidro." target="_blank">Enviar mensaje</a>
    </div>
</div>
<!-- <div class="item-info">
    <i class="las la-at"></i>
    <div class="item-textos">
        <h3>Email</h3>
        <a href="mailto:dr@adlerstein.com.ar">dr@adlerstein.com.ar</a>
    </div>
</div> -->
<div class="item-info">
    <i class="las la-map-marker"></i>
    <div class="item-textos">
        <h3>Consultorios</h3>
        <a href="contacto#mapas">Palermo, San Isidro, Belgrano.</a>
    </div>
</div>