<div class="ooss bg-primario pad-70">
    <div class="container">
        <div class="carousel-ooss">
            <div class="slide-item">
                <img src="img/ooss/smg.png" alt="Swiss Medical Group">
            </div>
            <div class="slide-item">
                <img src="img/ooss/osde.png" alt="Grupo OSDE">
            </div>
            <div class="slide-item">
                <img src="img/ooss/hospital-aleman.png" alt="Hospital Aleman">
            </div>
            <div class="slide-item">
                <img src="img/ooss/hospital-italiano.png" alt="Hospital Italiano">
            </div>
            <div class="slide-item">
                <img src="img/ooss/medicus.png" alt="Medicus Prepaga">
            </div>
            <div class="slide-item">
                <img src="img/ooss/bristol-medicine.png" alt="Bristol Medicine">
            </div>
            <div class="slide-item">
                <img src="img/ooss/accord.png" alt="Accord Salud">
            </div>
            <div class="slide-item">
                <img src="img/ooss/luis-pasteur.png" alt="Luis Pasteur">
            </div>
            <div class="slide-item">
                <img src="img/ooss/galeno.png" alt="Galeno">
            </div>
        </div>
    </div>
</div>